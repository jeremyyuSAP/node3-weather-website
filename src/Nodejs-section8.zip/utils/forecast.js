const needle = require('needle')

const forecast = (lat, long, callback) => {
    const url = 'http://api.weatherstack.com/current?access_key=596b82ba3be193284f2ed01f6a175f84&query=' + lat + ',' + long + '&units=f'

    needle({ url, json: true }, (error, { body }) => {
        if (error) {
            callback('Unable to connect to location services!', undefined)
        } else if (body.error > 0) {
            callback('Unable to find location. Try another search.', undefined)
        } else {
            callback(undefined, {
                location: body.location.name,
                region: body.location.region,
                temp: body.current.temperature,
                wind: body.current.weather_descriptions[0]
            })
        }
    })

}

module.exports = forecast